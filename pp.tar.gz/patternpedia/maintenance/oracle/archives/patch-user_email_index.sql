define mw_prefix='{$wgDBprefix}';

CREATE INDEX &mw_prefix.mwuser_i02 ON &mw_prefix.mwuser (user_email);

