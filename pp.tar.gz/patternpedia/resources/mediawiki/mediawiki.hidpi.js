jQuery( function ( $ ) {
	// Apply hidpi images on DOM-ready
	// Some may have already partly preloaded at low resolution.
	$( 'body' ).hidpi();
} );
