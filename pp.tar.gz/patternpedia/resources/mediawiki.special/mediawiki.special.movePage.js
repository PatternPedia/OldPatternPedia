/**
 * JavaScript for Special:MovePage
 */
jQuery( document ).ready( function ( $ ) {
	$( '#wpReason, #wpNewTitleMain' ).byteLimit();
} );
