/*
 * Namespace for mediawiki.special.* modules
 */

mediaWiki.special = {};
